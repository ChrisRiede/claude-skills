# Craft-Linsen je Form

Linsen sind Blickrichtungen, keine Checklisten: Sie sagen, wo man
hinschaut – nicht, was man findet. Welche Linse relevant ist, entscheidet
der konkrete Text. Nicht jede liefert bei jedem Text einen Befund, und
ein Befund außerhalb der Linsen zählt genauso.

## Erzählprosa (Geschichten)

- **Erzählinstanz und Distanz** – Wer erzählt, wie nah an der Figur, und
  bleibt das stabil? Unbeabsichtigte Sprünge verwirren.
- **Szene vs. Bericht** – Wird das Wichtige in Szene gezeigt oder nur
  zusammengefasst? Keine Doktrin, eine Dosierungsfrage: Wendepunkte
  vertragen selten Bericht.
- **Spannungsführung** – Welche offene Frage trägt den Leser weiter, und
  wo erschlafft sie?
- **Figurenlogik** – Handeln Figuren aus sich heraus oder weil der Plot
  es gerade braucht?
- **Konflikt und Fallhöhe** – Will die Hauptfigur etwas Konkretes, steht
  etwas dagegen, und was kostet das Scheitern? Ohne Einsatz keine
  Spannung – Sympathie allein trägt keine Geschichte.
- **Kausalität statt Episoden** – Folgen die Szenen mit „deshalb" und
  „aber" aufeinander oder nur mit „und dann"? Reihung ermüdet,
  Verkettung zieht.
- **Szenenökonomie** – Bewegt jede Szene den Plot oder eine Figur? Was
  beides nicht tut, ist Streichkandidat – egal wie schön geschrieben.
- **Exposition** – Wird Hintergrund eingewoben (über Handlung, Detail,
  Reibung im Dialog) oder als Info-Block abgeladen?
- **Dialog** – Klingt er gesprochen? Trägt er Subtext oder nur
  Information?
- **Anfang und Ende** – Verspricht der Anfang, was der Text einlöst?
  Löst das Ende ein – oder erklärt es nur?

## Gedicht

- **Bildlogik** – Sind die Bilder eigen und in sich stimmig, oder
  Erste-Idee-Metaphern, die jeder schreiben würde?
- **Konkretion** – Trägt Sinnliches das Abstrakte, oder behauptet der
  Text Gefühle nur?
- **Klang und Rhythmus** – Laut lesen: Wo stolpert es? Bei gebundener
  Form: Trägt das Metrum, oder wird es erzwungen (Füllwörter, verdrehte
  Syntax dem Reim zuliebe)?
- **Zeilenbrüche** – Arbeiten die Brüche (Betonung, Doppeldeutung am
  Zeilenende), oder sind sie zufällig?
- **Verdichtung** – Welche Wörter verdient der Text nicht? Jedes Wort
  muss arbeiten.
- **Kitsch-Radar** – Wo rutscht echtes Gefühl in Formel?

## Lied / Songtext

- **Prosodie zuerst** – Zeilen laut sprechen: Landen betonte Silben auf
  starken Zählzeiten? Eine falsch betonte Silbe klingt sofort
  amateurhaft – das ist der häufigste Fehler und deshalb die erste
  Prüfung.
- **Struktur und Payoff** – Baut die Strophe die Spannung auf, die der
  Refrain auflöst? Gewinnt der Refrain bei jeder Wiederholung Bedeutung
  dazu, oder nutzt er sich ab?
- **Hook** – Sitzt die Kernzeile prominent (oft erste oder letzte Zeile
  des Refrains)? Bleibt sie nach einmal Hören?
- **Sangbarkeit** – Offene Vokale auf langen Tönen, Konsonantencluster,
  Atemstellen: singbar oder Zungenbrecher?
- **Reim** – Rein oder unrein bewusst gewählt? Erwartbare Paare
  (Herz/Schmerz-Klasse) gegen überraschende, die trotzdem natürlich
  fallen?
- **Register** – Spricht da eine Figur oder dichtet da jemand? Passt die
  Sprachebene zu Genre und Stimme?
- **Mit oder ohne Melodie** – Der Nutzer arbeitet mal mit, mal ohne
  Melodie/Akkorde. Liegt eine vor: Prosodie gegen die konkrete Melodie
  prüfen. Ohne: das Betonungsmuster des Textes selbst prüfen und
  kritische Stellen fürs spätere Vertonen markieren.

### Genre-Profil: Malle-/Partyschlager

Bevorzugtes Lied-Genre des Nutzers (Referenzkünstler: Julian Sommer –
z. B. „Dicht im Flieger" – und Mia Julia). Hier zeigt sich „am eigenen
Anspruch messen"
in Reinform – mehrere Standard-Linsen kehren sich um:

- **Mitgröl-Test schlägt alles** – Kann eine angetrunkene Menge den
  Refrain nach einmal Hören mitbrüllen? Kurze Zeilen, wenige Töne,
  eingängige Melodik ohne Sprünge, offene Vokale. Das ist das
  Abnahmekriterium des Genres.
- **Klischee ist Werkzeug, nicht Schwäche** – Kitsch-Radar und
  Originalitätsanspruch gelten hier nicht. Vertraute Bilder und Phrasen
  machen sofort mitsingbar; gesucht wird der eine frische Dreh
  (Titelzeile, Wortspiel, Szene), nicht durchgehende Poesie.
- **Reim: simpel, rein, erwartbar** – Die Menge muss den Reim kommen
  hören und mitrufen können. Erwartbarkeit ist hier Feature, nicht Fehler.
- **Hook = Titel = Spruch** – Die Kernzeile funktioniert auch ohne Musik
  als Zuruf oder T-Shirt-Slogan (Zuruf-Test). Wiederholung: mehr ist
  mehr; Chants und Silbenketten (Oh-oh-oh, Lelele) sind legitime
  Bausteine, keine Verlegenheit.
- **Wir-Gefühl und kurze Strophen** – Ansprache der Menge, Themen:
  Feiern, Saufen, Malle, Freundschaft, Selbstironie, Eskalation mit
  Augenzwinkern. Strophen sind Anlauf für den Refrain, kein Erzählraum.
- **Zote mit Timing** – Stumpfe, sexuell anzügliche Doppeldeutigkeiten
  gehören zum Register des Genres; Mia Julia hat eine ganze Karriere
  darauf gebaut. Handwerklich zählt: Der Gag sitzt auf dem Beat, bleibt
  mitgrölbar und zwinkert – die Menge lacht **mit** dem Song. Plump ist
  erlaubt und oft genau der Punkt; nur bemüht oder erklärend darf es nie
  werden, und eine Doppeldeutigkeit braucht wirklich beide Lesarten –
  sonst ist sie nur die eine.
- **Energie-Architektur** – Treibender 4/4 zum Klatschen und Springen,
  Spannungs-Break vor dem Refrain, Hände-hoch-Moment. Prosodie bleibt
  trotzdem König: Auch betrunken muss die Betonung von selbst richtig
  fallen.

## Andere Formen

Essay, Sketch, Drehbuchszene, was auch immer: Die Linsen sinngemäß
ableiten – was ist die Kernmechanik dieser Form, und dient jede
Entscheidung im Text ihr?
