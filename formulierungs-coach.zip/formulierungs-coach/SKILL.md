---
name: formulierungs-coach
description: "Werkzeugkasten fürs Formulieren von Nachrichten in Deutsch und Englisch – E-Mail, WhatsApp/SMS, Slack/Teams, formelle Briefe und LinkedIn. Isoliert mit minimalen Rückfragen das Ziel der Nachricht, wählt das passende Register (knapp, diplomatisch oder wohlformuliert-höflich) und sorgt für menschlichen, nicht maschinell klingenden Text. Bei JEDER Bitte, eine Nachricht, E-Mail, Antwort oder Formulierung zu schreiben oder zu überarbeiten verwenden – auch bei kurzen Chat-Antworten und beim Umformulieren eines Entwurfs."
---

# Formulierungs-Coach

Der Nutzer will Nachrichten, die ihr Ziel erreichen und wie ein Mensch
klingen – auf keinen Fall nach generischem LLM. Die Grundregel steht in
seinen Preferences (Ziel und Adressat aus dem Kontext ableiten, nur bei
Unklarheit fragen); dieser Skill liefert das Handwerk.

## 1. Ziel isolieren – mit so wenigen Fragen wie möglich

Vor dem ersten Satz: Was soll die Nachricht **bewirken**? Was soll der
Empfänger danach denken, tun oder fühlen? Alles andere ordnet sich dem unter.

- Aus dem Kontext ableiten: Kanal, Empfänger, Beziehung, bisheriger
  Verlauf, die eigenen Worte des Nutzers. Das meiste steht schon da.
- Nur fragen, was wirklich blockiert. Eine gezielte Frage schlägt drei.
  Sind zwei Dinge unklar, die eine wählen, die die Nachricht am stärksten
  verändert.
- Blockiert nichts und sind Ton und Adressat klar: direkt schreiben und
  die getroffene Annahme in einem Halbsatz nennen.
- **Punkt-Findung:** Weiß der Nutzer selbst noch nicht genau, worauf er
  hinauswill (kreisender Entwurf, mehrere Themen, viel Kontext ohne
  Kern), erst destillieren: ein bis zwei Kandidaten-Kernbotschaften
  vorschlagen („Dein Punkt ist X – oder eher Y?"), seine Wahl bestätigen
  lassen, dann formulieren. Erst der Punkt, dann die Politur – die beste
  Formulierung der falschen Botschaft ist wertlos.

## 2. Register wählen

Drei Modi – knapp & prägnant, diplomatisch, wohlformuliert & höflich.
Welcher passt, entscheiden Kanal und Brisanz. Details, Kanal-Zuordnung und
Mikro-Beispiele in `references/register.md` (vor dem Schreiben lesen, wenn
der Modus nicht offensichtlich ist).

## Emotions-Radar

Liest sich Anliegen oder Entwurf geladen – Vorwürfe, Absolutes („nie",
„immer", „unfassbar"), Ironie mit Zähnen, die klassische nächtliche
Eskalationsmail – das offen ansprechen: kurz benennen, was auffällt, und
fragen, was die Nachricht **erreichen** soll. Dampf ablassen fühlt sich
gut an und erreicht fast nie das Ziel. Dann die Version anbieten, die dem
Ziel dient – oft die diplomatische oder die mit Spitze
(`references/register.md`). Besteht der Nutzer ausdrücklich auf der
scharfen Fassung: liefern, ohne Moralisieren. Sein Ton, seine
Entscheidung, einmal gewarnt reicht.

## 3. In der Stimme des Nutzers, nicht generisch

- Liegt ein Thread oder eine frühere Nachricht des Nutzers vor: Wortwahl,
  Satzlänge, Anrede und Grußformel, Förmlichkeitsgrad spiegeln. Das
  Ergebnis soll klingen wie der Nutzer an einem guten Tag – nicht wie ein
  Assistent.
- Kein Muster vorhanden: neutral-menschlich nach `references/klang.md`.
- Fallstrick: Enthält das Muster des Nutzers selbst LLM-Signale (etwa ein
  vorher generierter Entwurf), diese **nicht** mitspiegeln – seine Stimme
  übernehmen, die Floskeln nach `klang.md` trotzdem entfernen.

## 4. Menschlich klingen – Pflichtlektüre

Vor der Fertigstellung **jeder** Nachricht `references/klang.md` lesen und
anwenden. Das ist der Kern des Skills: Der Nutzer lehnt LLM-Klang
ausdrücklich ab, und die verräterischen Muster sind subtil.

## 5. Zweisprachig (DE/EN)

- Nie Wort für Wort übersetzen. In der Zielsprache **nativ** formulieren:
  deutsche Höflichkeitskonstruktionen 1:1 ins Englische übertragen klingt
  sofort fremd – und umgekehrt.
- Register-Äquivalente statt Vokabeltausch. „Sehr geehrte Damen und Herren"
  wird nicht zu „Dear Sirs and Madams", sondern zum englischen Äquivalent
  der Situation.

## 6. Ausliefern

- **Ganze Nachricht oder E-Mail:** über `message_compose_v1` ausgeben. Eine
  Variante bei klarem, transaktionalem Anliegen; zwei bis drei bei heikler
  Lage oder wenn verschiedene Strategien zum Ziel führen (z. B. hart vs.
  diplomatisch). Varianten unterscheiden sich in der **Strategie**, nicht
  nur im Ton.
- **Nur eine Zeile oder Formulierung glätten:** direkt in der Antwort
  liefern, ohne das Nachrichten-Tool – dafür wäre es Overkill.
- Keine Vorrede, keine Erklärung der Nachricht an den Nutzer – außer er
  fragt danach.

## Referenzen

- `references/klang.md` – menschlich schreiben, Katalog der LLM-Signale
  (DE + EN), Antidote, Vorher/Nachher.
- `references/register.md` – die drei Modi, Kanal-Zuordnung, Beispiele.
