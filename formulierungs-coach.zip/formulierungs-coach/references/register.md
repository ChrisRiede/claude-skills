# Register: drei Modi + Kanäle

Register ist eine Blickrichtung, kein Formular. Eine Nachricht darf
mischen, und kein Modus schaltet die Regeln aus `klang.md` ab.

## Modus 1 — Knapp & prägnant

- **Wann:** Empfänger hat wenig Zeit, die Sache ist klar, keine
  Beziehungsspannung. Ziel: in Sekunden verstanden.
- **Merkmale:** ein Gedanke pro Satz, kein Vorspann, aktive Verben. Im
  Chat sind unvollständige Sätze und knappe/keine Anrede in Ordnung.
- **Default für:** WhatsApp/SMS, die meisten Slack/Teams-Nachrichten.

## Modus 2 — Diplomatisch

- **Wann:** Konflikt, schlechte Nachricht, Absage, Kritik, Verhandlung,
  heikle Beziehung. Ziel: die Sache klar sagen, ohne die Beziehung zu
  beschädigen.
- **Merkmale:** Anliegen klar benennen, nicht verschleiern – aber die
  Rahmung wählen: Gemeinsames oder Anerkennung zuerst, Position begründen,
  dem Gegenüber Raum und einen Ausweg lassen. Weich in der Form, hart in
  der Sache. Kein Passiv-Aggressiv, keine falsche Wärme, keine
  Weichspüler, die die Botschaft unklar machen.
- **Default für:** keinen festen Kanal – Modus 2 greift quer über alle
  Kanäle, sobald etwas auf dem Spiel steht.

### Schärferegler: höflich mit Spitze

Auf ausdrücklichen Wunsch des Nutzers (oder wenn er es erkennbar will)
darf Modus 2 Zähne zeigen – untadelig höflich, unangreifbar, und der
Empfänger spürt es trotzdem. Werkzeuge:

- **Übergenaue Chronik** – Fakten, Daten, Zusagen nüchtern aufreihen
  („wie am 3., am 12. und zuletzt am 28. erbeten"). Die Liste spricht,
  nicht der Ton.
- **Betonte Förmlichkeit als Distanz** – plötzlich sehr korrekt werden,
  wo vorher lockerer Ton war. Der Registerwechsel selbst ist die
  Botschaft.
- **Lob des Selbstverständlichen** – „Danke, dass Sie sich der Sache nun
  annehmen."
- **Scheinbar naive Rückfrage** – „Nur damit ich es richtig verstehe:
  Die Zusage vom 3. gilt nicht mehr?"
- **Präzise Erwartung mit Frist** statt Vorwurf – „Ich gehe davon aus,
  dass X bis Freitag vorliegt."

Regeln: Die Spitze muss **abstreitbar** bleiben – das ist ihr ganzer
Witz. Jeder Satz muss einzeln vor Dritten bestehen (Chef, Gericht,
Screenshot). Keine Beleidigung, kein Sarkasmus mit Ausrufezeichen: Wer
sichtbar sticht, hat verloren.

## Modus 3 — Wohlformuliert & höflich

- **Wann:** formeller Anlass, unbekannter oder hochrangiger Empfänger,
  Behörde, Bewerbung, offizielle Anfrage. Ziel: Kompetenz und Respekt
  zeigen.
- **Merkmale:** vollständige Anrede und Grußformel, ganze Sätze, korrekte
  Form – aber trotzdem klar und ohne Nominalstil-Ballast. Höflich heißt
  nicht geschwollen.
- **Default für:** Brief/Behörde, formelle Erst-E-Mail,
  LinkedIn-Erstkontakt.

## Kanal-Schnellzuordnung (Startpunkt, kein Gesetz)

| Kanal | Start-Modus | Ton |
|---|---|---|
| WhatsApp/SMS privat | 1 | sehr locker; Ellipsen ok, Emojis nur, wenn der Nutzer sie sonst nutzt |
| Slack/Teams | 1 | kollegial; ein Satz reicht meist |
| Berufliche E-Mail | 2 oder 3 | Standard klar-freundlich, nicht steif; nach Empfänger und Anlass |
| Formell/Behörde/LinkedIn | 3 | korrekt, aber ohne Floskeln |

**Brisanz schlägt Kanal:** Sobald Spannung, Konflikt oder eine schlechte
Nachricht im Spiel ist, überschreibt Modus 2 die Kanal-Vorgabe – auch in
WhatsApp oder Slack.

## Mischen ist normal

Eine kurze Absage per Slack ist knapp **und** diplomatisch. Eine formelle
Mail an eine vertraute Kollegin ist höflich, aber lockerer als an eine
Behörde. Den konkreten Fall lesen, nicht das Etikett.
