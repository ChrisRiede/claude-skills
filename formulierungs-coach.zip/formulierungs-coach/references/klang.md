# Menschlich schreiben, nicht LLM

Der wichtigste Anspruch des Nutzers. LLM-Klang entsteht durch drei Dinge:
Glätte, Symmetrie und Allgemeinheit. Menschlicher Klang entsteht durch das
Gegenteil: Konkretheit, Rhythmuswechsel, Weglassen. Faustregel: Würde ein
Mensch mit wenig Zeit das genau so tippen? Klingt es wie eine Vorlage, ist
es eine.

## Antidote (was aktiv tun)

- **Konkret statt allgemein.** Die Sache beim Namen nennen, nicht die
  Kategorie: „dein Entwurf zur API-Migration" statt „dein wertvoller
  Beitrag". Konkretheit ist das stärkste Einzelmittel gegen generischen
  Klang.
- **Mit dem Punkt beginnen**, nicht mit Räuspern.
- **Satzlängen mischen.** Ein kurzer Satz. Dann einer, der etwas weiter
  ausholt, einen Gedanken entwickelt und erst am Ende landet. Gleich lange,
  gleich gebaute Sätze sind das deutlichste Maschinensignal.
- **Verben statt Nominalstil:** „damit wir schneller entscheiden" statt
  „zur Beschleunigung der Entscheidungsfindung".
- **Hedges und Verstärker streichen:** eigentlich, quasi, natürlich,
  selbstverständlich / just, really, very, actually.
- **Kleine Unregelmäßigkeiten stehen lassen.** Menschen sind nicht
  durchparallelisiert. Nicht jeder Aufzählung muss ein Dreiklang sein.
- **Nicht mit einer Zusammenfassung enden**, die wiederholt, was gerade
  dastand.

## Deutsche Warnsignale (streichen oder ersetzen)

- **Leere Öffner:** „Ich hoffe, diese E-Mail erreicht Sie wohlbehalten",
  „Ich hoffe, es geht Ihnen gut", „Ich wollte mich kurz bei Ihnen melden".
  Direkt zum Anliegen.
- **Floskel-Übergänge in Serie:** zudem, darüber hinaus, des Weiteren,
  ferner – nicht mehr als einen, und nur wenn er echte Verbindung schafft.
- **Consulting-Sprech:** nahtlos, robust, ganzheitlich, maßgeschneidert,
  Mehrwert, Synergien, proaktiv, auf Augenhöhe, jemanden „abholen".
- **Konjunktiv-Türme:** „Ich würde mich freuen, wenn Sie mir mitteilen
  könnten, ob es Ihnen möglich wäre …" → „Können Sie mir sagen, ob …".
- **Nominalstil-Ketten:** „zur Sicherstellung der Optimierung des
  Prozesses" → „damit der Prozess besser läuft".
- **Füll-Einschübe:** „Es ist wichtig zu erwähnen, dass", „An dieser
  Stelle sei angemerkt".
- **Pflicht-Schluss:** „Zögern Sie nicht, sich bei Fragen zu melden."

## Englische Warnsignale

- **Empty openers:** I hope this email finds you well; I wanted to reach
  out; I hope you're doing well.
- **Antithesis-Tic:** „It's not just X, it's Y", „It's not about X, it's
  about Y" – einmal wirkt es, in Serie ist es Maschine.
- **Reflex-Dreiklänge:** clear, concise, and compelling – alles in Dreien.
- **Signposting:** Firstly … Secondly … In conclusion; gestapeltes
  Moreover / Furthermore / Additionally.
- **Buzzwords:** delve, leverage, utilize, facilitate, seamless,
  streamline, robust, navigate the complexities, in today's fast-paced
  world, landscape, realm, tapestry, testament to.
- **Filler:** It's worth noting that; Feel free to; Don't hesitate to.
- **Vage Begeisterung:** I'm thrilled, excited to connect, great to e-meet.
- **Closing restatement**, der die Mail zusammenfasst.

## Vorher / Nachher (zeigt das Prinzip, ist keine Vorlage)

Diese Paare demonstrieren den Griff – nicht zum Abschreiben, sondern um
das Muster zu sehen.

**DE, E-Mail, Bitte um Feedback**
- Vorher (LLMig): „Ich hoffe, diese Nachricht erreicht Sie gut. Ich wollte
  mich bei Ihnen melden, um höflich anzufragen, ob Sie eventuell die
  Möglichkeit hätten, mir Ihr wertvolles Feedback zu meinem Entwurf
  zukommen zu lassen. Über eine baldige Rückmeldung würde ich mich sehr
  freuen."
- Nachher: „Hallo Frau Berg, könnten Sie bis Donnerstag über meinen
  Entwurf schauen? Beim zweiten Abschnitt bin ich unsicher, ob die
  Richtung stimmt. Danke!"

**EN, Slack, eine Absage**
- Vorher: „Thank you so much for thinking of me! I would absolutely love
  to help, however I'm currently at capacity. I truly appreciate your
  understanding and please don't hesitate to reach out in the future."
- Nachher: „Thanks for the ping — I can't take this on this week, I'm
  slammed. Ask me again next week?"

## Menschlich ≠ immer locker

Die Warnsignale gelten in **jedem** Register. Ein förmlicher Brief bleibt
förmlich – aber klar, direkt und ohne Floskelballast. Was zwischen den
Registern variiert, ist die Lockerheit, nicht die Ehrlichkeit des Tons.
Höflich und geschwollen sind nicht dasselbe.
