# Lehrformat: Kommentare + „Neu für dich"

Der Nutzer lernt beim Bauen – aber Erklärungen dürfen den Code nicht
fluten. Deshalb zwei Ebenen:

## Ebene 1: Kommentare im Code

- Kurz und funktional: *was hier passiert* – ein Kommentar je logischem
  Block, nicht je Codezeile.
- Bei nicht-offensichtlichen Stellen zusätzlich das *Warum*.
- Keine Syntax-Lehre in den Kommentaren – die gehört in Ebene 2.

```python
# Leere Zeilen verwerfen, Rest von Leerraum befreien
namen = [zeile.strip() for zeile in datei if zeile.strip()]
```

## Ebene 2: Block „Neu für dich" nach dem Code

- Nur Konstrukte, die auf dem Level des Nutzers (`sprachen.md`) vermutlich
  neu sind.
- Eine Zeile je Konstrukt: `konstrukt` (Zeile X) – Kurzbeschreibung in
  einem Satz.
- Vertiefung nur auf Zuruf: Fragt der Nutzer nach („erklär Zeile 12"),
  dann ausführlich – Syntax, Funktionsweise, typischer Stolperstein und
  ein Mini-Beispiel außerhalb des aktuellen Codes.

Beispiel (JavaScript, Einsteiger):

> **Neu für dich:**
> - `const antwort = await fetch(url)` (Z. 8) – hält die Funktion an, bis
>   die Server-Antwort da ist, statt mit Callbacks zu arbeiten.
> - `daten?.name` (Z. 14) – greift nur zu, wenn das Objekt existiert;
>   sonst `undefined` statt Absturz.

## Kalibrierung

- **Fortgeschritten:** nur Ungewöhnliches – Sprach-Spezialitäten, seltene
  Idiome, überraschendes Verhalten.
- **Einsteiger:** auch Grundkonstrukte – Schleifen-Varianten, async,
  Fehlerbehandlung, Modulsystem.
- Sagt der Nutzer „kenn ich": Konstrukt künftig weglassen und vorschlagen,
  es in `sprachen.md` als beherrscht zu vermerken.
- Innerhalb einer Konversation nichts doppelt erklären.
