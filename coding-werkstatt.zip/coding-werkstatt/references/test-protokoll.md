# Test-Protokoll

Erst verifizieren, dann deklarieren: Der häufigste Fehlermodus
KI-generierten Codes ist selbstbewusst übergebener Code, dessen Kernlogik
nie gelaufen ist.

## Vorab: Fertig-Kriterien

Vor der Implementierung 3–7 prüfbare Kriterien festhalten („Fertig
heißt: …"). Bei allem Sichtbaren gehört dazu: Rendering auf Desktop und
Mobil geprüft. Bei der Übergabe bekommt jedes Kriterium einen Status:
**verifiziert**, **offen** oder **nicht prüfbar** (mit Grund).

## Testreihenfolge

1. **Happy Path** – der normale, beabsichtigte Ablauf.
2. **Randfälle** – systematisch: leere Eingabe, `null`/`None`, 0 und
   negative Zahlen, sehr große Werte, Sonderzeichen/Umlaute/Emoji,
   Duplikate, exakte Grenzwerte (off-by-one). Diese generische Liste ist
   die Untergrenze, nicht der Abschluss – dazu kommen die Randfälle, die
   nur dieses Programm hat (Fachlogik, Datenformate, Zustände).
3. **Nutzer-Simulation** – sich verhalten wie echte Menschen: Dinge in
   falscher Reihenfolge tun, doppelt klicken, ungültige Eingaben schicken,
   mittendrin abbrechen, dasselbe zweimal gleichzeitig starten.
4. **Fehlerpfade** – jede erwartbare Ausnahme gezielt provozieren: Kommt
   eine verständliche Meldung oder ein Absturz? Bleibt der Zustand
   konsistent? Das gilt ausdrücklich auch für neu eingebaute
   Fehlerbehandlung: Code, der Fehler abfangen soll, wird durch genau
   diese Fehler getestet – nicht nur über den Happy Path.
5. **UI-Rendering** (bei allem Sichtbaren) – `scripts/ui_check.py`
   ausführen: Seite laden, reale Bedienpfade klicken, Screenshots in
   Desktop- (1280 px) und Mobilbreite (390 px). Die Screenshots ansehen
   und bewerten: Überlappt etwas? Text abgeschnitten? Klickpfad intakt?
   Grüne Logik-Tests ersetzen nie den Blick aufs echte Rendering.

## Regression: nach jeder Änderung alles erneut

Nach **jedem** Fix, **jedem** Einbau von Fehlerbehandlung und **jedem**
Refactoring laufen alle bisherigen Tests erneut – nicht nur der eine, der
vorher rot war. Ein Fix, der woanders etwas bricht, ist kein Fix. Erst
wenn die komplette Suite nach der letzten Änderung grün war, gilt der
Stand als getestet.

## Eiserne Regeln

- Nie einen Test löschen, abschwächen, auskommentieren oder mit
  Sonderfällen austricksen, um Grün zu erzwingen. Wer den Test ändert
  statt den Code, versteckt den Befund nur.
- Einzige legitime Ausnahme: Die Anforderung selbst hat sich geändert und
  macht den Test obsolet. Dann: Test anpassen oder entfernen UND im
  Änderungsprotokoll begründen.
- Kein „sollte funktionieren". Jede Aussage über Funktionsfähigkeit
  braucht einen Nachweis. Was nicht lief, wird als „ungetestet, weil …"
  ausgewiesen.

## Wenn der Code lokal beim Nutzer läuft

Hier kann nicht selbst getestet werden – also bekommt der Nutzer ein
Testpaket:

- Exakte Kommandos in Ausführungsreihenfolge, inklusive Installation und
  Abhängigkeiten.
- Zu jedem Kommando die erwartete Ausgabe – und woran ein Fehlschlag
  erkennbar wäre.
- Die wichtigsten 2–3 Randfälle als konkrete manuelle Prüfschritte.
