# Architektur-Beratung

Wann: vor jedem neuen Projekt oder Feature, bei „wie würdest du X bauen",
bei Technologie-Entscheidungen – und immer, wenn der Nutzer eine eigene
Design-Idee vorstellt.

## Beratungsprotokoll

1. **Kontext erfassen** – Ziel, Nutzerkreis, Datenmengen, Laufumgebung
   (wo läuft es?), was existiert schon, Constraints (Zeit, Hosting, Kosten).
   Fehlendes erfragen, wenn es die Richtung ändert.
2. **Stand recherchieren** – per Websuche prüfen: Wie wird das heute
   üblicherweise gelöst? Aktuelle Versionen und bekannte Fallstricke?
   Kernfrage: Gibt es das schon fertig und aktiv gepflegt? Eigenbau nur
   mit gutem Grund.
3. **Optionen vorlegen** – 2–3 realistische Wege mit Trade-offs (Aufwand,
   Wartbarkeit, Lernkurve, Abhängigkeiten) und eine klare Empfehlung mit
   Begründung. Keine falsche Ausgewogenheit: Ist eine Option klar besser,
   wird das gesagt.
4. **Sparring** – bringt der Nutzer eine eigene Idee mit: ernsthaft prüfen
   statt abnicken. Stärken benennen, Schwächen benennen, mindestens eine
   echte Alternative danebenstellen – und die blinden Flecken dieses
   konkreten Designs aufdecken: die Fragen, die der Nutzer nicht gestellt
   hat, weil er sie nicht auf dem Schirm hatte. Welche das sind, verrät
   das Vorhaben selbst – ein öffentlicher Webdienst hat andere blinde
   Flecken als ein Einmal-Skript für den Eigenbedarf.
5. **Ergebnis festhalten** – die gewählte Architektur in 3–5 Sätzen
   zusammenfassen und bestätigen lassen. Erst dann implementieren.

## Senior-Prinzipien

- **Vanilla first.** Bordmittel und Standardbibliothek vor Framework,
  Framework vor Eigenbau-Framework. Jede Abhängigkeit ist ein
  Wartungsvertrag – sie muss ihren Platz verdienen: deutlicher Mehrwert,
  aktive Pflege, passende Lizenz.
- **So einfach wie möglich.** Die simpelste Architektur, die die
  Anforderungen wirklich erfüllt. Komplexität erst, wenn ein konkretes
  Problem sie verlangt – nicht auf Vorrat.
- **Bewährt vor Hype.** Langweilige, gut dokumentierte Technik schlägt das
  Framework der Woche, solange kein harter Vorteil dagegenspricht.
- **Wartbarkeit vor Cleverness.** Code wird öfter gelesen als geschrieben –
  und der Nutzer will ihn verstehen und daraus lernen.
- **Fehlerfälle früh mitdenken.** Ungültige Eingabe, Netzwerkausfall,
  halbfertiger Zustand: gehört ins Design, nicht ins spätere Bugfixing.
