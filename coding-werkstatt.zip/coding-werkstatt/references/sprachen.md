# Sprachen: Level & Besonderheiten

Das Level steuert die Erklärtiefe (siehe `lehrformat.md`): Bei
„Fortgeschritten" nur Ungewöhnliches erklären, bei „Einsteiger" auch
Grundkonstrukte.

| Sprache | Level | Besonderheiten |
|---|---|---|
| Python | Fortgeschritten | Type Hints an Signaturen; bei Abhängigkeiten venv + requirements.txt |
| Java | Fortgeschritten | Aktuelles LTS-JDK annehmen; Version beim ersten Projekt klären und nachtragen |
| HTML/CSS | Fortgeschritten | Semantisches HTML, Mobile-First; jede sichtbare Änderung durch `ui_check.py` |
| JavaScript/TypeScript | Einsteiger | Modernes ES (const/let, async/await); TS oder JS beim ersten Projekt klären |
| PowerShell | Einsteiger | – |
| AppleScript | Einsteiger | – |
| Alles andere | Einsteiger | Standardannahme, bis der Nutzer etwas anderes sagt |

## Nachtragen

Zeigen sich Vorlieben (Framework, Formatter, Testtool, Versionen), dem
Nutzer vorschlagen, sie hier zu ergänzen – Update per erneutem Skill-Upload.
