#!/usr/bin/env python3
"""
UI-Check: Lädt eine Seite im Headless-Browser, klickt optional Bedienpfade
durch und erzeugt Screenshots in Desktop- und Mobilbreite.

Verwendung:
    python ui_check.py SEITE [--click SELEKTOR ...] [--out VERZEICHNIS]

SEITE kann eine URL (http/https) oder der Pfad zu einer lokalen
HTML-Datei sein.
"""

import argparse
import sys
from pathlib import Path

# Zwei Ansichten, die reale Geräte abbilden: klassischer Desktop
# und eine gängige Smartphone-Breite (iPhone-Klasse)
ANSICHTEN = {
    "desktop": {"width": 1280, "height": 800},
    "mobil": {"width": 390, "height": 844},
}


def main() -> int:
    parser = argparse.ArgumentParser(
        description="Screenshots und Klickpfade für die UI-Prüfung"
    )
    parser.add_argument("seite", help="URL oder Pfad zur HTML-Datei")
    parser.add_argument(
        "--click", action="append", default=[],
        help="CSS-Selektor, der nach dem Laden geklickt wird "
             "(mehrfach möglich, Reihenfolge zählt)",
    )
    parser.add_argument(
        "--out", default="ui_screenshots",
        help="Zielverzeichnis für die Screenshots",
    )
    args = parser.parse_args()

    # Playwright erst hier importieren, damit bei fehlender Installation
    # eine klare Anleitung statt eines nackten ImportError erscheint
    try:
        from playwright.sync_api import Error as PlaywrightError
        from playwright.sync_api import sync_playwright
    except ImportError:
        print("FEHLER: Playwright ist nicht installiert.", file=sys.stderr)
        print("Installation:  pip install playwright && playwright install chromium",
              file=sys.stderr)
        print("Fallback ohne Playwright: HTML im Browser öffnen und manuell in",
              file=sys.stderr)
        print("Desktop- (1280 px) und Mobilbreite (390 px) prüfen.",
              file=sys.stderr)
        return 2

    # Lokale Dateipfade in file://-URLs umwandeln, echte URLs unverändert lassen
    ziel = args.seite
    if not ziel.startswith(("http://", "https://", "file://")):
        pfad = Path(ziel).resolve()
        if not pfad.exists():
            print(f"FEHLER: Datei nicht gefunden: {pfad}", file=sys.stderr)
            return 2
        ziel = pfad.as_uri()

    ausgabe = Path(args.out)
    ausgabe.mkdir(parents=True, exist_ok=True)

    konsole_meldungen: list[str] = []
    exit_code = 0

    with sync_playwright() as pw:
        browser = pw.chromium.launch()
        for name, groesse in ANSICHTEN.items():
            page = browser.new_page(viewport=groesse)

            # JS-Fehler der Seite einsammeln – sie sind im Screenshot
            # unsichtbar, machen die Seite aber oft funktionsunfähig
            def _konsole(msg, ansicht=name):
                if msg.type in ("error", "warning"):
                    konsole_meldungen.append(f"[{ansicht}] {msg.type}: {msg.text}")

            page.on("console", _konsole)
            page.on(
                "pageerror",
                lambda err, ansicht=name: konsole_meldungen.append(
                    f"[{ansicht}] Seitenfehler: {err}"
                ),
            )

            try:
                # 30 s Timeout deckt auch langsame Verbindungen ab
                page.goto(ziel, wait_until="networkidle", timeout=30_000)
            except PlaywrightError as e:
                print(f"FEHLER beim Laden ({name}): {e}", file=sys.stderr)
                exit_code = 1
                page.close()
                continue

            page.screenshot(path=str(ausgabe / f"{name}_0_start.png"),
                            full_page=True)

            # Bedienpfad durchklicken – jeder Schritt bekommt einen
            # eigenen Screenshot, damit der Zustand nachvollziehbar ist
            for i, selektor in enumerate(args.click, start=1):
                try:
                    page.click(selektor, timeout=5_000)
                    # Kurze Pause, damit Animationen/Nachladen sichtbar werden
                    page.wait_for_timeout(500)
                    page.screenshot(
                        path=str(ausgabe / f"{name}_{i}_{_kurzname(selektor)}.png"),
                        full_page=True,
                    )
                except PlaywrightError as e:
                    print(f"KLICK FEHLGESCHLAGEN ({name}, Schritt {i}, "
                          f"'{selektor}'): {e}", file=sys.stderr)
                    page.screenshot(
                        path=str(ausgabe / f"{name}_{i}_FEHLER.png"),
                        full_page=True,
                    )
                    exit_code = 1

            page.close()
        browser.close()

    # Zusammenfassung: erzeugte Screenshots und gesammelte Konsolenmeldungen
    print(f"\nScreenshots liegen in: {ausgabe.resolve()}")
    for datei in sorted(ausgabe.glob("*.png")):
        print(f"  - {datei.name}")

    if konsole_meldungen:
        exit_code = 1
        print("\nKONSOLEN-MELDUNGEN der Seite (Fehler/Warnungen):",
              file=sys.stderr)
        for zeile in konsole_meldungen:
            print(f"  {zeile}", file=sys.stderr)
    else:
        print("Keine Konsolenfehler registriert.")

    print("\nWICHTIG: Screenshots jetzt ansehen und bewerten – "
          "Erzeugen allein ist kein Test.")
    return exit_code


def _kurzname(selektor: str) -> str:
    """Macht aus einem CSS-Selektor einen dateinamentauglichen Kurznamen."""
    erlaubt = "".join(c if c.isalnum() else "_" for c in selektor)
    return erlaubt[:30] or "klick"


if __name__ == "__main__":
    sys.exit(main())
