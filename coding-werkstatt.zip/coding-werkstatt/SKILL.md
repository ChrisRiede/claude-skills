---
name: coding-werkstatt
description: "Werkzeugkasten für alle Programmier- und Code-Aufgaben in Python, Java, JavaScript/TypeScript, HTML/CSS, PowerShell, AppleScript u. a.: Architektur-Beratungsprotokoll mit Recherche und Optionsvergleich, Randfall-Checkliste und Regressions-Regeln fürs Testen, UI-Screenshot-Skript für Desktop und Mobil, Sprachlevel des Nutzers und Lehrformat für Code-Erklärungen. Bei JEDER Coding-Aufgabe verwenden – auch bei kleinen Skripten, Bugfixes, Code-Reviews, Refactorings und Debugging."
---

# Coding-Werkstatt

Die Arbeitsregeln des Nutzers – Testdisziplin, robuster Code ohne Stubs,
deutsche Kommentare, Transparenz bei Änderungen, Vanilla first,
Selbstprüfung vor jeder Funktioniert-Behauptung – stehen in seinen
Preferences und gelten immer. Dieser Skill wiederholt sie nicht, sondern
liefert die Werkzeuge, um sie umzusetzen.

## Werkzeuge – und wann welches

- `references/architektur.md` – Vor jedem neuen Projekt oder Feature, bei
  Technologie-Entscheidungen und wenn der Nutzer eine eigene Design-Idee
  vorstellt. Enthält Beratungsprotokoll, Senior-Prinzipien und Vanilla first.
- `references/sprachen.md` – Vor dem Schreiben von Code lesen: das Level je
  Sprache steuert die Erklärtiefe.
- `references/lehrformat.md` – Bei jeder Code-Übergabe: wie Kommentare und
  der „Neu für dich"-Block aussehen.
- `references/test-protokoll.md` – Bei jeder nicht-trivialen Aufgabe:
  Fertig-Kriterien, Randfall-Checkliste, Regression, lokales Testpaket.
- `scripts/ui_check.py` – Bei allem Sichtbaren:
  `python scripts/ui_check.py seite.html --click "#selektor"` erzeugt
  Screenshots in Desktop- und Mobilbreite, klickt Bedienpfade durch und
  sammelt Konsolenfehler. Screenshots ansehen und bewerten, nicht nur
  erzeugen.

## Verifizieren beim Schreiben, nicht erst beim Testen

Die typische Fehlklasse „diese Methode funktioniert – hoppla, gibt es gar
nicht / nicht in dieser Kombination" entsteht beim Schreiben, nicht beim
Testen. Deshalb: Unsichere API-Signaturen, Bibliotheks-Kombinationen und
alles, was nach dem Trainingsstand erschienen sein könnte, vor der
Verwendung prüfen – per Mini-Testlauf in der Umgebung (ein Import, ein
Aufruf) oder per Doku/Websuche. Je exotischer die Kombination, desto
höher die Prüfpflicht.

## Verhältnismäßigkeit

Bei trivialen, leicht umkehrbaren Aufgaben genügt vorab ein Satz zu Vorgehen
und Fertig-Kriterium. Testen und Lehrformat gelten trotzdem immer.

## Skill aktuell halten

Zeigen sich wiederkehrende Vorlieben oder Projektkonventionen (Framework,
Formatter, JDK-Version, TypeScript vs. JS), dem Nutzer vorschlagen, sie in
`references/sprachen.md` nachzutragen – Update per erneutem Skill-Upload.
