# Quellen: Hierarchien, Warnsignale, Querlesen

Die Rangfolge hängt vom Fragetyp ab – eine Einheitsliste gibt es nicht.
Die Hierarchien sind Ausgangspunkte, keine Dogmen: Eine methodisch starke
Quelle niedriger Kategorie schlägt eine schwache Quelle hoher Kategorie.

## Hierarchie je Fragetyp

**Wissenschaft & Gesundheit**
Systematische Reviews und Metaanalysen → Einzelstudien (peer-reviewed;
auf Stichprobengröße und Methodik achten – peer-reviewed heißt nicht
automatisch verlässlich, Rückzüge kommen vor) → Fachgesellschaften und
Behörden → Preprints (als vorläufig kennzeichnen) →
Wissenschaftsjournalismus.

**Nachrichten & Ereignisse**
Originaldokumente, offizielle Mitteilungen, Primäraufnahmen →
Nachrichtenagenturen und Medien mit eigener Recherche vor Ort →
Einordnung durch Qualitätsmedien → Aggregatoren (nur als Wegweiser zur
eigentlichen Quelle).

**Technik & Software**
Offizielle Doku und Changelogs → Quellcode und Issue-Tracker →
Maintainer-Blogs → geprüfte Community-Antworten (Datum prüfen –
Technik-Antworten altern schnell) → Tutorials Dritter.

**Produkte & Kauf**
Unabhängige Testinstitute mit Messwerten → Fachtests mit offengelegter
Methodik → aggregierte Nutzererfahrungen (Muster zählen, nicht
Einzelstimmen) → Affiliate-„Bestenlisten" (praktisch wertlos).

**Recht & Amtliches**
Gesetzestext und Urteil im Original → amtliche Erläuterungen →
Fachkommentare und Kanzlei-Beiträge (Rechtsstand und Datum prüfen).

## Warnsignale

- Kein Autor, kein Datum, keine Quellenangaben.
- Zirkularität: viele Treffer, aber alle führen auf dieselbe
  Ursprungsquelle zurück – Sekundärketten, in denen eine Aussage immer
  weiter zitiert wird, ohne je zum Original zu führen.
- Interessenkonflikt: Verkäufer, Affiliate-Links, gesponserte Studien –
  nicht automatisch falsch, aber nie als einzige Basis.
- SEO-Textwüsten: viel Wortzahl, keine prüfbaren Aussagen.
- Zu glatt: nur eine Seite kommt vor, keine Einschränkungen, keine
  offenen Fragen.

## Studien & Daten lesen (wissenschaftlicher Standard)

- **Studienlage vor Einzelstudie** – eine Studie ist ein Datenpunkt, kein
  Beweis. Gibt es Replikationen, Reviews, Metaanalysen? Widerspricht der
  Befund dem bisherigen Kenntnisstand, braucht er entsprechend stärkere
  Belege.
- **Methodik vor Schlagzeile** – Wer wurde untersucht, wie viele, wie
  gemessen? Randomisiertes Experiment oder Beobachtung? Korrelation ist
  keine Kausalität – wer hat für Störfaktoren kontrolliert?
- **Effektgröße vor Signifikanz** – „statistisch signifikant" heißt nicht
  „praktisch bedeutsam". Absolute Zahlen vor relativen: ein „verdoppeltes
  Risiko" kann 0,001 % → 0,002 % bedeuten.
- **Interessen und Finanzierung** – Wer hat die Studie bezahlt, wer
  profitiert vom Ergebnis? Nicht automatisch disqualifizierend, aber nie
  als einzige Basis.
- **Publikationsbias mitdenken** – Negativ- und Nullbefunde werden
  seltener veröffentlicht; die sichtbare Literatur überzeichnet Effekte.
- **Unsicherheit gehört in den Befund** – Spannbreiten und
  Konfidenzintervalle nennen statt Scheinpräzision; was die Studienlage
  nicht hergibt, wird nicht behauptet.

## Querlesen (Kurzprotokoll)

Die Methode professioneller Faktenchecker (lateral reading): Bei einer
unbekannten Quelle nicht auf der Seite bleiben und ihre Selbstauskunft
lesen, sondern die Seite verlassen und in einer eigenen Suche prüfen –
Wer betreibt das? Welche Interessen? Wie schätzen unabhängige Dritte die
Quelle ein? Gab es Korrekturen oder Skandale? Zwei Minuten Querlesen
ersparen die Analyse einer wertlosen Quelle.
