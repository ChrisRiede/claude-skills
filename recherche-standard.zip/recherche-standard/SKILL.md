---
name: recherche-standard
description: "Werkzeugkasten für alle Recherche- und Lern-Aufgaben: Tiefen-Staffelung vom Schnell-Check bis zur Tiefenrecherche, Prüfprotokoll mit Originalquellen und Querlesen, fragetyp-abhängige Quellenhierarchien, Sicherheitsgrade für Befunde, Umgang mit Widersprüchen und Lernmodus mit Nicht-gefragt-aber-wichtig-Block. Bei JEDER Faktenfrage, Produkt- oder Technologiewahl, Nachrichtenlage, wissenschaftlichen oder strittigen Frage verwenden – und bei JEDER Lern- und Verständnisfrage (erklär mir, wie funktioniert, was ist, warum), auch bei beiläufigen Stimmt-das-eigentlich-Fragen."
---

# Recherche-Standard

Die Grundregeln stehen in den Preferences des Nutzers: immer Quellen,
primäre bevorzugen, Widersprüche ausweisen, Konsens von Umstrittenem
trennen. Dieser Skill liefert das Handwerk dazu.

## Gründlich schlägt schnell

Der Nutzer wählt ausdrücklich Gründlichkeit vor Geschwindigkeit.
**Standard ist das volle Protokoll.** Der Schnell-Check (1–2 verlässliche
Quellen, Antwort mit Beleg) ist die Ausnahme für triviale, folgenlose
Einzelfakten – und selbst dann gilt: im Zweifel eskalieren.
Grundhaltung: Behauptungen sind Hypothesen, bis Belege sie tragen – auch
die eigenen Zwischenergebnisse werden hinterfragt, nicht nur fremde
Aussagen.

## Protokoll Tiefenrecherche

1. **Frage schärfen** – Was genau muss beantwortet sein, damit der Nutzer
   entscheiden kann? Das unterscheidet Recherche von Sammeln – und
   verhindert Kaninchenbau-Abstiege in Nebenschauplätze.
2. **Breit suchen, dann Original lesen** – Suchtreffer-Snippets sind
   Wegweiser, keine Belege: Die tragenden Quellen vollständig abrufen.
   Behauptungen, Zitate und Zahlen bis zur Originalquelle zurückverfolgen,
   nicht beim Nacherzähler stoppen.
3. **Quer lesen statt tief glauben** – Eine unbekannte Quelle nicht nach
   ihrer Selbstdarstellung beurteilen, sondern verlassen und prüfen, was
   unabhängige Dritte über sie sagen (`references/quellen.md`).
4. **Unabhängigkeit prüfen** – Zehn Artikel, die dieselbe eine
   Pressemitteilung nacherzählen, sind eine Quelle, nicht zehn.
5. **Die stärkste Gegenposition suchen** – aktiv nach Belegen gegen den
   sich abzeichnenden Befund suchen, und zwar nach den besten, nicht den
   dümmsten. Hält der Befund das aus, ist er belastbar.
6. **Evidenz wissenschaftlich wiegen** – bei Studien, Statistiken und
   empirischen Behauptungen den Abschnitt „Studien & Daten lesen" in
   `references/quellen.md` anwenden: Methodik vor Schlagzeile,
   Effektgröße vor Signifikanz, Studienlage vor Einzelstudie.
7. **Befund mit Sicherheitsgrad und Stand-Datum** – siehe unten.

## Lernmodus – Verstehen statt Entscheiden

Lernfragen („erklär mir X", „wie funktioniert Y") laufen mit derselben
Gründlichkeit und denselben Quellen- und Evidenzstandards – nur das Ziel
ist Verstehen statt Entscheiden. Zusätzlich gilt:

- **Vom Kern zur Tiefe** – zuerst das tragende Prinzip in wenigen Sätzen
  (die Intuition), dann die Mechanik, dann Grenzfälle und Ausnahmen.
  Kein Referat-Aufbau: Der Nutzer will sofort den Punkt, nicht die
  Hinführung.
- **Fehlvorstellung zuerst ausräumen** – gibt es zum Thema eine
  verbreitete falsche Intuition, wird sie früh benannt und korrigiert.
  Das ist meist der größte Lern-Hebel.
- **„Nicht gefragt, aber wichtig"** – am Ende höchstens 1–3 Punkte, je
  ein bis zwei Sätze: die Frage hinter der Frage, der entscheidende
  Vorbehalt, das direkt angrenzende Konzept. Vertiefung nur auf
  Nachfrage. Gibt es nichts Wesentliches, entfällt der Block ersatzlos –
  er ist ein Qualitätsversprechen, kein Ritual.

## Sicherheitsgrade

- **Belegt** – mehrere unabhängige, verlässliche Quellen; keine ernsthafte
  Gegenposition gefunden.
- **Wahrscheinlich** – gute, aber dünne oder einseitige Beleglage.
- **Umstritten** – seriöse Quellen widersprechen sich; beide Seiten mit
  ihren jeweils besten Argumenten darstellen.
- **Unklar** – Beleglage reicht nicht; benennen, was fehlt, statt die
  Lücke zu füllen.

## Aktualität

Bei allem, was sich ändern kann – Preise, Versionen, Rechtslage, Ämter,
Forschungsstand – junge Quellen bevorzugen, das Stand-Datum in den Befund
schreiben („Stand: Monat Jahr") und Trainingswissen nicht mit aktueller
Lage verwechseln.

## Referenz

- `references/quellen.md` – Quellenhierarchien je Fragetyp, Warnsignale,
  Querlese-Protokoll.
